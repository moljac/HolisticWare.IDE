# Xamarin Component Sample 

This project is placeholder for sample Xamarin Component intended to explain component packaging

## Sample Project structure 

*	./bat		
	*	scripts for compiling, copying and packing
*	./sbin		
	utilites used for packing or 
*	./content	
	content for component
	*	documentation - markdown
	*	icons	
		* 128 x 128		
		* 512 x 512		
	*	samples			
		
*	./bat		
*	./bat		
	




